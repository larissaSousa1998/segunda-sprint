create database bdJordan;
use bdJordan;

create table user(
    id int primary key auto_increment,
    foto varchar(50),
    nome varchar(50),
    email varchar(50),
    senha varchar(50)
);

insert into user (nome,email,senha) values 
("Lucas Matheus","lcs.11mat@gmail.com","escutarpozenaopode"),
("Barreira","barreira.bar@bandtec.com","Hostpot");

select * from user;
