

let teste = [];
function pegarusuario(){
    let div = document.querySelector("#msg")
    let ajax = new XMLHttpRequest();
    ajax.open("GET","http://localhost:3000/user",true);
    ajax.onreadystatechange =function(){
        if(ajax.readyState==XMLHttpRequest.DONE){
            let array = ajax.responseText;
            
             teste= JSON.parse(array);
             

            console.log(array);
           
            

        }
    }
    ajax.send();
}

let form = document.querySelector("#formulario");
let nome = document.querySelector('#input_nome');
let email = document.querySelector('#input_email');
let senha = document.querySelector('#input_senha');

function addUser(evento){
    evento.preventDefault();

    let ajax =  new XMLHttpRequest();

    let params = "nome=" + nome.value + "&email=" + email.value + "&senha=" + senha.value;

    ajax.open("POST","http://localhost:3000/addUser");
    ajax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    ajax.onreadystatechange=function(){
        if(ajax.status==200 & ajax.readyState==4){
            console.log(ajax.responseText);

        }
       
    }
    ajax.send(params);

}

form.addEventListener("submit",addUser);