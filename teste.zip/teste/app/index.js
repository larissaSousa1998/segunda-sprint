const express = require('express');
const app = express();

const connection = require('./connection');
const bodyParser = require('body-parser');

const cors = require ('cors');

const port = 3000;

app.use(cors());
app.use(bodyParser.urlencoded({extended: true}));

app.get('/',(req,res)=>{
    res.send('Alo');
});

app.get('/user',(req,res)=>{
    connection.query("SELECT id,nome,email,senha FROM user",function(err,result){
        if(err) throw err;
        res.send(result);
    })
});

app.post('/addUser',(req,res)=>{
    let data=[req.body.nome, req.body.email, req.body.senha];

    let sql = "INSERT INTO user (nome,email,senha) values (?,?,?)";


    connection.query(sql,data,function(err,result){
        if(err) throw err;
        res.send(result);
    });

    
})

app.listen(port, function(){
    console.log('Servidor rodando na porta '+port);
});
